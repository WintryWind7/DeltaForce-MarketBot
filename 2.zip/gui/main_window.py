#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主窗口类
"""

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QLabel, QPushButton, QTextEdit, QStatusBar,
    QStackedWidget, QFrame, QGridLayout,
    QSpinBox, QDoubleSpinBox, QScrollArea, QFormLayout, QLineEdit
)
from PySide6.QtCore import Qt, QSize, QTimer
from PySide6.QtGui import QIcon, QFont, QColor, QWheelEvent

import sys
import os
import json

# 自定义控件类，禁用滚轮事件
class NoWheelSpinBox(QSpinBox):
    """禁用滚轮事件的QSpinBox"""
    def wheelEvent(self, event):
        # 忽略滚轮事件，不调用父类的wheelEvent
        event.ignore()

class NoWheelDoubleSpinBox(QDoubleSpinBox):
    """禁用滚轮事件的QDoubleSpinBox"""
    def wheelEvent(self, event):
        # 忽略滚轮事件，不调用父类的wheelEvent
        event.ignore()

# 添加当前目录到路径，确保可以导入task_logger
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

# 添加DeltaForce目录到路径
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'DeltaForce'))
from DeltaForceClass import DeltaForceClass

class MainWindow(QMainWindow):
    """主窗口类"""
    
    def __init__(self, delta=None):
        super().__init__()
        self.current_page = "action"  # 当前页面
        self.current_action = None  # 当前选中的行为
        
        # 使用传入的DeltaForce实例，如果没有则创建新的
        if delta is not None:
            self.delta = delta
        else:
            # 兼容直接启动主窗口的情况
            from DeltaForceClass import DeltaForceClass
            self.delta = DeltaForceClass()
        
        # 进程监控相关
        self.process_widgets = {}  # 存储进程显示组件
        self.last_processes = []   # 上次检测到的进程
        self.process_roles = {}    # 存储进程的主辅角色 {hwnd: 'main'/'aux'}
        
        # 创建定时器用于实时更新进程信息
        self.process_timer = QTimer()
        self.process_timer.timeout.connect(self.update_process_info)
        self.process_timer.start(2000)  # 每2秒更新一次
        
        # 移除脚本管理器，只使用behavior模块
        
        # 行为线程管理
        self.current_behavior = None
        self.input_monitor = None
        
        # 行为管理器
        from gui.behavior_manager import BehaviorManager
        self.behavior_manager = BehaviorManager()
        
        # 配置控件存储
        self.config_widgets = {}  # 存储各个行为的配置控件 {behavior_id: {param_name: widget}}
        
        # 配置文件路径
        self.config_file = "behavior_configs.json"
        
        # 加载保存的配置
        self.saved_configs = self.load_configs()
        
        self.init_ui()
        
    def init_ui(self):
        """初始化用户界面"""
        # 设置窗口基本属性
        self.setWindowTitle("DeltaForce MarketBot")
        self.setMinimumSize(QSize(800, 600))
        self.resize(1000, 700)
        
        # 创建中央窗口部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # 创建主布局（水平布局：左侧导航栏 + 右侧内容区）
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 创建左侧导航栏
        self.create_sidebar(main_layout)
        
        # 创建右侧内容区域
        self.create_main_content(main_layout)
        
        # 创建状态栏
        self.create_status_bar()
        
    def create_sidebar(self, parent_layout):
        """创建左侧导航栏"""
        sidebar_widget = QWidget()
        sidebar_widget.setFixedWidth(200)
        sidebar_widget.setStyleSheet("""
            QWidget {
                background-color: #2c3e50;
                color: white;
            }
            QPushButton {
                background-color: #34495e;
                border: none;
                color: white;
                padding: 15px;
                text-align: left;
                font-size: 14px;
                margin: 2px;
            }
            QPushButton:hover {
                background-color: #3498db;
            }
            QPushButton:pressed {
                background-color: #2980b9;
            }
            QPushButton[selected="true"] {
                background-color: #3498db;
                font-weight: bold;
            }
        """)
        
        sidebar_layout = QVBoxLayout(sidebar_widget)
        sidebar_layout.setContentsMargins(0, 0, 0, 0)
        sidebar_layout.setSpacing(0)
        
        # 应用标题
        title_label = QLabel("DeltaForce MarketBot")
        title_label.setFont(QFont("", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("padding: 20px; background-color: #1a252f; color: white;")
        sidebar_layout.addWidget(title_label)
        
        # 导航按钮
        self.nav_buttons = {}
        
        # 行为按钮（第一个）
        action_btn = QPushButton("⚡ 行为")
        action_btn.clicked.connect(lambda: self.switch_page("action"))
        action_btn.setProperty("selected", "true")
        self.nav_buttons["action"] = action_btn
        sidebar_layout.addWidget(action_btn)
        
        # 主页按钮
        main_btn = QPushButton("🏠 主页")
        main_btn.clicked.connect(lambda: self.switch_page("main"))
        self.nav_buttons["main"] = main_btn
        sidebar_layout.addWidget(main_btn)
        
        # 进程按钮
        process_btn = QPushButton("🖥️ 进程")
        process_btn.clicked.connect(lambda: self.switch_page("process"))
        self.nav_buttons["process"] = process_btn
        sidebar_layout.addWidget(process_btn)
        
        # 执行记录按钮
        history_btn = QPushButton("📊 执行记录")
        history_btn.clicked.connect(lambda: self.switch_page("history"))
        self.nav_buttons["history"] = history_btn
        sidebar_layout.addWidget(history_btn)
        
        # 设置按钮
        settings_btn = QPushButton("⚙️ 设置")
        settings_btn.clicked.connect(lambda: self.switch_page("settings"))
        self.nav_buttons["settings"] = settings_btn
        sidebar_layout.addWidget(settings_btn)
        
        # 日志按钮
        log_btn = QPushButton("📋 日志")
        log_btn.clicked.connect(lambda: self.switch_page("log"))
        self.nav_buttons["log"] = log_btn
        sidebar_layout.addWidget(log_btn)
        
        # 关于按钮
        about_btn = QPushButton("ℹ️ 关于")
        about_btn.clicked.connect(lambda: self.switch_page("about"))
        self.nav_buttons["about"] = about_btn
        sidebar_layout.addWidget(about_btn)
        
        # 添加弹性空间
        sidebar_layout.addStretch()
        
        # 刷新按钮（底部）
        refresh_btn = QPushButton("🔄 刷新")
        refresh_btn.clicked.connect(self.refresh_all_content)
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                border: none;
                color: white;
                padding: 12px;
                text-align: center;
                font-size: 13px;
                font-weight: bold;
                margin: 5px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #2ecc71;
            }
            QPushButton:pressed {
                background-color: #229954;
            }
        """)
        sidebar_layout.addWidget(refresh_btn)
        
        parent_layout.addWidget(sidebar_widget)
        
    def create_main_content(self, parent_layout):
        """创建右侧主内容区域"""
        # 创建堆叠窗口部件用于切换不同页面
        self.stacked_widget = QStackedWidget()
        
        # 创建各个页面
        self.create_action_page()
        self.create_main_page()
        self.create_process_page()
        self.create_task_history_page()  # 新增执行记录页面
        self.create_settings_page()
        self.create_log_page()
        self.create_about_page()
        
        parent_layout.addWidget(self.stacked_widget)
        
    def create_action_page(self):
        """创建行为页面"""
        # 创建行为页面的堆叠窗口
        self.action_stacked = QStackedWidget()
        
        # 创建行为选择页面
        self.create_action_selection_page()
        
        # 创建具体行为设置页面
        self.create_action_detail_pages()
        
        self.stacked_widget.addWidget(self.action_stacked)
        
    def create_action_selection_page(self):
        """创建行为选择页面"""
        selection_page = QWidget()
        layout = QVBoxLayout(selection_page)
        layout.setContentsMargins(10, 10, 10, 10)
        
        # 页面标题
        title = QLabel("选择执行行为")
        title.setFont(QFont("", 18, QFont.Bold))
        layout.addWidget(title)
        
        # 创建自定义滚动区域
        scroll_area = self.create_smooth_scroll_area()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: transparent;
            }
            QScrollBar:vertical {
                background-color: #f0f0f0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #c0c0c0;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #a0a0a0;
            }
        """)
        
        # 行为列表容器
        actions_container = QWidget()
        actions_layout = QVBoxLayout(actions_container)
        actions_layout.setContentsMargins(0, 0, 0, 0)
        actions_layout.setSpacing(8)
        
        # 从行为管理器获取行为列表
        behavior_list = self.behavior_manager.get_behavior_list()
        
        if not behavior_list:
            # 如果没有找到行为，显示提示
            no_behavior_label = QLabel("未找到可用的行为模块")
            no_behavior_label.setAlignment(Qt.AlignCenter)
            no_behavior_label.setStyleSheet("color: #7f8c8d; font-size: 14px; padding: 40px;")
            actions_layout.addWidget(no_behavior_label)
        else:
            # 创建行为卡片
            for behavior in behavior_list:
                # 为不同行为设置不同图标
                icon_map = {
                    "test_300_behavior": "💰",
                    "dual_window_919_behavior": "🔄",
                    "dual_window_919_record_behavior": "📹",
                    "DMR000X": "🎯",  # 双端刷新购买
                    "SMB000X": "💰",  # 单端购买刷新
                    "SSS000X": "🎯",  # 单端枪皮
                    "SPR000X": "💎",  # 单端价格刷新
                    "SPR919G": "💎",  # 单端价格刷新919G
                    "DMB000X": "🔄",  # 双端满仓
                    "test_basic_behavior": "🔧",
                    "custom_behavior": "📝"
                }
                
                action_data = {
                    "id": behavior['id'],
                    "name": behavior['title'],
                    "description": behavior['description'],
                    "icon": icon_map.get(behavior['id'], "⚡"),
                    "version": behavior.get('version', '1.0.0'),
                    "author": behavior.get('author', 'Unknown'),
                    "tags": behavior.get('tags', [])
                }
                
                action_card = self.create_action_card(action_data)
                actions_layout.addWidget(action_card)
        
        # 添加弹性空间到容器底部
        actions_layout.addStretch()
        
        # 将容器设置到滚动区域
        scroll_area.setWidget(actions_container)
        
        # 将滚动区域添加到主布局
        layout.addWidget(scroll_area)
        
        self.action_stacked.addWidget(selection_page)
        
    def create_action_card(self, action):
        """创建行为卡片"""
        card = QFrame()
        card.setFrameStyle(QFrame.Box)
        # 设置固定高度，防止被压缩
        card.setFixedHeight(120)
        card.setMinimumWidth(500)
        card.setStyleSheet("""
            QFrame {
                border: 2px solid #ddd;
                border-radius: 10px;
                padding: 8px;
                margin: 2px;
                background-color: white;
            }
            QFrame:hover {
                border-color: #3498db;
                background-color: #f8f9fa;
            }
        """)
        card.setCursor(Qt.PointingHandCursor)
        
        layout = QHBoxLayout(card)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(8)
        
        # 左侧图标
        icon_label = QLabel(action["icon"])
        icon_label.setFont(QFont("", 28))
        icon_label.setFixedSize(70, 70)
        icon_label.setAlignment(Qt.AlignCenter)
        icon_label.setStyleSheet("border: none; background-color: #ecf0f1; border-radius: 35px;")
        layout.addWidget(icon_label)
        
        # 右侧信息
        info_layout = QVBoxLayout()
        info_layout.setContentsMargins(0, 0, 0, 0)
        info_layout.setSpacing(2)
        
        # 标题和标签的水平布局
        title_row_layout = QHBoxLayout()
        title_row_layout.setContentsMargins(0, 0, 0, 0)
        title_row_layout.setSpacing(8)
        
        name_label = QLabel(action["name"])
        name_label.setFont(QFont("Microsoft YaHei", 16, QFont.Bold))
        title_row_layout.addWidget(name_label)
        
        # 添加标签
        if action.get("tags") and len(action["tags"]) > 0:
            for tag in action["tags"]:
                tag_label = QLabel(tag)
                tag_label.setStyleSheet("""
                    QLabel {
                        background-color: #3498db;
                        color: white;
                        border-radius: 10px;
                        padding: 6px 12px;
                        font-size: 14px;
                        font-weight: bold;
                        margin: 0px 4px;
                    }
                """)
                tag_label.setFont(QFont("Microsoft YaHei", 14, QFont.Bold))
                tag_label.setFixedHeight(32)
                tag_label.setAlignment(Qt.AlignCenter)
                title_row_layout.addWidget(tag_label)
        
        title_row_layout.addStretch()
        info_layout.addLayout(title_row_layout)
        
        desc_label = QLabel(action["description"])
        desc_label.setStyleSheet("color: #666; font-size: 14px;")
        desc_label.setWordWrap(True)
        desc_label.setFont(QFont("Microsoft YaHei", 14))
        info_layout.addWidget(desc_label)
        
        layout.addLayout(info_layout)
        layout.addStretch()
        
        # 添加点击事件
        card.mousePressEvent = lambda event, action_id=action["id"]: self.select_action(action_id)
        
        return card
        
    def create_action_detail_pages(self):
        """创建具体行为的详细设置页面"""
        # 动态为所有behavior创建详细页面
        behavior_list = self.behavior_manager.get_behavior_list()
        
        for behavior in behavior_list:
            self.create_behavior_detail_page(behavior)
    
    def create_behavior_detail_page(self, behavior):
        """创建通用的行为详细设置页面"""
        detail_page = QWidget()
        layout = QVBoxLayout(detail_page)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 返回按钮和标题
        header_layout = QHBoxLayout()
        
        back_btn = QPushButton("← 返回选择")
        back_btn.clicked.connect(lambda: self.action_stacked.setCurrentIndex(0))
        back_btn.setStyleSheet("QPushButton { background-color: #95a5a6; color: white; padding: 8px 15px; border-radius: 5px; }")
        header_layout.addWidget(back_btn)
        
        header_layout.addStretch()
        
        title = QLabel(f"{behavior['title']} 设置")
        title.setFont(QFont("", 18, QFont.Bold))
        header_layout.addWidget(title)
        
        header_layout.addStretch()
        layout.addLayout(header_layout)
        
        # 行为描述
        desc_label = QLabel(behavior['description'])
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet("color: #7f8c8d; font-size: 14px; margin: 10px 0px;")
        layout.addWidget(desc_label)
        
        # 版本和作者信息
        info_layout = QHBoxLayout()
        version_label = QLabel(f"版本: {behavior.get('version', '1.0.0')}")
        version_label.setStyleSheet("color: #95a5a6; font-size: 12px;")
        info_layout.addWidget(version_label)
        
        author_label = QLabel(f"作者: {behavior.get('author', 'Unknown')}")
        author_label.setStyleSheet("color: #95a5a6; font-size: 12px;")
        info_layout.addWidget(author_label)
        
        info_layout.addStretch()
        layout.addLayout(info_layout)
        
        # 分隔线
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        line.setStyleSheet("color: #bdc3c7;")
        layout.addWidget(line)
        
        # 配置区域（支持自定义参数）
        config_label = QLabel("配置选项:")
        config_label.setFont(QFont("", 14, QFont.Bold))
        config_label.setStyleSheet("margin-top: 20px;")
        layout.addWidget(config_label)
        
        # 创建配置控件容器
        config_container = self.create_config_container(behavior)
        layout.addWidget(config_container)
        
        # 弹性空间
        layout.addStretch()
        
        # 执行按钮
        execute_btn = QPushButton(f"执行 {behavior['title']}")
        execute_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                padding: 12px 24px;
                border-radius: 6px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
            QPushButton:pressed {
                background-color: #21618c;
            }
        """)
        execute_btn.clicked.connect(lambda: self.execute_action(behavior['id']))
        layout.addWidget(execute_btn)
        
        # 添加到堆栈
        self.action_stacked.addWidget(detail_page)
    
    def create_config_container(self, behavior):
        """创建配置参数容器"""
        behavior_info = self.behavior_manager.get_behavior_info(behavior['id'])
        
        # 检查是否有自定义配置
        if not behavior_info or 'module' not in behavior_info:
            # 没有自定义配置，显示默认提示
            config_info = QLabel("该行为使用默认配置运行。")
            config_info.setStyleSheet("color: #7f8c8d; font-size: 12px; margin: 10px 0px;")
            return config_info
        
        module = behavior_info['module']
        
        # 每次都从磁盘重新加载模块，支持热更新
        custom_config = {}
        
        try:
            # 动态重新加载behavior模块
            import importlib.util
            import os
            
            behavior_file = f"gui/behavior/{behavior['id']}.py"
            if os.path.exists(behavior_file):
                # 重新加载模块
                spec = importlib.util.spec_from_file_location(behavior['id'], behavior_file)
                fresh_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(fresh_module)
                
                # 尝试获取Behavior类并调用get_ui_config
                behavior_class = None
                if hasattr(fresh_module, 'get_behavior_class'):
                    behavior_class = fresh_module.get_behavior_class()
                else:
                    # 查找继承自Behavior的类
                    for name in dir(fresh_module):
                        obj = getattr(fresh_module, name)
                        if (isinstance(obj, type) and 
                            hasattr(obj, '__bases__') and
                            any('Behavior' in str(base) for base in obj.__bases__)):
                            behavior_class = obj
                            break
                
                if behavior_class and hasattr(behavior_class, 'get_ui_config'):
                    try:
                        custom_config = behavior_class.get_ui_config()
                        print(f"✅ 从磁盘重新加载{behavior['id']}的UI配置")
                    except Exception as e:
                        print(f"⚠️ 获取{behavior['id']}的UI配置失败: {e}")
                        custom_config = {}
                
                # 如果新方式失败，回退到旧的BEHAVIOR_INFO方式
                if not custom_config:
                    custom_config = getattr(fresh_module, 'BEHAVIOR_INFO', {}).get('custom_config', {})
                    if custom_config:
                        print(f"✅ 使用{behavior['id']}的BEHAVIOR_INFO配置")
            else:
                print(f"❌ 行为文件不存在: {behavior_file}")
                
        except Exception as e:
            print(f"❌ 重新加载{behavior['id']}失败: {e}")
            # 如果重新加载失败，回退到缓存的模块
            if 'module' in behavior_info:
                module = behavior_info['module']
                custom_config = getattr(module, 'BEHAVIOR_INFO', {}).get('custom_config', {})
        
        if not custom_config:
            # 没有自定义配置，显示默认提示
            config_info = QLabel("该行为使用默认配置运行。")
            config_info.setStyleSheet("color: #7f8c8d; font-size: 12px; margin: 10px 0px;")
            return config_info
        
        # 创建滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setMaximumHeight(300)
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: 1px solid #ddd;
                border-radius: 5px;
                background-color: #f9f9f9;
            }
        """)
        
        # 创建配置表单
        config_widget = QWidget()
        form_layout = QFormLayout(config_widget)
        form_layout.setSpacing(10)
        
        # 初始化该行为的配置控件字典
        if behavior['id'] not in self.config_widgets:
            self.config_widgets[behavior['id']] = {}
        
        # 为每个配置参数创建控件
        processed_params = set()  # 记录已处理的参数
        for param_name, param_config in custom_config.items():
            # 跳过已处理的参数（如分钟参数会在小时参数处理时一起创建）
            if param_name in processed_params:
                continue
            param_type = param_config.get('type', 'int')
            label_text = param_config.get('label', param_name)
            default_value = param_config.get('default', 0)
            description = param_config.get('description', '')
            
            # 检查是否有保存的配置值
            if (behavior['id'] in self.saved_configs and 
                param_name in self.saved_configs[behavior['id']]):
                default_value = self.saved_configs[behavior['id']][param_name]
            
            # 特殊处理：时间参数（小时和分钟组合）
            if param_name.endswith('_hour'):
                minute_param_name = param_name.replace('_hour', '_minute')
                if minute_param_name in custom_config:
                    # 标记分钟参数已处理
                    processed_params.add(minute_param_name)
                    
                    # 创建时间组合控件
                    time_label_text = label_text.replace('-时', '')  # 移除"-时"后缀
                    label = QLabel(f"{time_label_text}:")
                    label.setStyleSheet("font-weight: bold; color: #2c3e50;")
                    
                    # 创建水平布局容纳小时和分钟输入框
                    time_container = QWidget()
                    time_layout = QHBoxLayout(time_container)
                    time_layout.setContentsMargins(0, 0, 0, 0)
                    time_layout.setSpacing(5)
                    
                    # 创建小时输入框
                    hour_widget = NoWheelSpinBox()
                    hour_min = param_config.get('min', 0)
                    hour_max = param_config.get('max', 23)
                    hour_widget.setMinimum(hour_min)
                    hour_widget.setMaximum(hour_max)
                    hour_widget.setValue(int(default_value))
                    hour_widget.setStyleSheet("""
                        QSpinBox {
                            padding: 5px;
                            border: 1px solid #bdc3c7;
                            border-radius: 3px;
                            font-size: 12px;
                            min-width: 50px;
                        }
                        QSpinBox:focus {
                            border-color: #3498db;
                        }
                    """)
                    
                    # 创建分钟输入框
                    minute_config = custom_config[minute_param_name]
                    minute_default = minute_config.get('default', 0)
                    if (behavior['id'] in self.saved_configs and 
                        minute_param_name in self.saved_configs[behavior['id']]):
                        minute_default = self.saved_configs[behavior['id']][minute_param_name]
                    
                    minute_widget = NoWheelSpinBox()
                    minute_min = minute_config.get('min', 0)
                    minute_max = minute_config.get('max', 59)
                    minute_widget.setMinimum(minute_min)
                    minute_widget.setMaximum(minute_max)
                    minute_widget.setValue(int(minute_default))
                    minute_widget.setStyleSheet("""
                        QSpinBox {
                            padding: 5px;
                            border: 1px solid #bdc3c7;
                            border-radius: 3px;
                            font-size: 12px;
                            min-width: 50px;
                        }
                        QSpinBox:focus {
                            border-color: #3498db;
                        }
                    """)
                    
                    # 添加到布局
                    time_layout.addWidget(hour_widget)
                    time_layout.addWidget(QLabel(":"))
                    time_layout.addWidget(minute_widget)
                    time_layout.addStretch()
                    
                    # 存储控件引用
                    self.config_widgets[behavior['id']][param_name] = hour_widget
                    self.config_widgets[behavior['id']][minute_param_name] = minute_widget
                    
                    # 连接信号
                    hour_widget.valueChanged.connect(self.on_config_changed)
                    minute_widget.valueChanged.connect(self.on_config_changed)
                    
                    # 特殊处理：24小时自动转为23:59
                    def handle_hour_change(value, h_widget=hour_widget, m_widget=minute_widget):
                        if value == 24:
                            h_widget.setValue(23)
                            m_widget.setValue(59)
                    hour_widget.valueChanged.connect(handle_hour_change)
                    
                    # 添加到表单
                    form_layout.addRow(label, time_container)
                    continue  # 跳过后续的普通控件创建逻辑
            
            # 创建标签
            label = QLabel(f"{label_text}:")
            label.setStyleSheet("font-weight: bold; color: #2c3e50;")
            
            # 根据类型创建对应的控件
            if param_type == 'int' and param_name == 'debug_mode':
                # 特殊处理：debug_mode 使用循环按钮（0→1→2→0）
                widget = QPushButton()
                # 设置初始值
                try:
                    int_value = int(default_value) if default_value is not None else param_config.get('default', 0)
                    # 确保值在有效范围内
                    int_value = max(0, min(2, int_value))
                except (ValueError, TypeError):
                    int_value = 0
                
                # 存储当前值（使用对象属性）
                widget.current_value = int_value
                
                # 更新按钮文本和样式
                def make_update_debug_button_style(btn):
                    def update_style(value):
                        if value == 0:
                            btn.setText("✗ 关闭")
                            btn.setStyleSheet("""
                                QPushButton {
                                    background-color: #95a5a6;
                                    color: white;
                                    border: none;
                                    padding: 8px 16px;
                                    border-radius: 4px;
                                    font-size: 12px;
                                    font-weight: bold;
                                }
                                QPushButton:hover {
                                    background-color: #7f8c8d;
                                }
                                QPushButton:pressed {
                                    background-color: #707b7c;
                                }
                            """)
                        elif value == 1:
                            btn.setText("🔍 简化Debug")
                            btn.setStyleSheet("""
                                QPushButton {
                                    background-color: #3498db;
                                    color: white;
                                    border: none;
                                    padding: 8px 16px;
                                    border-radius: 4px;
                                    font-size: 12px;
                                    font-weight: bold;
                                }
                                QPushButton:hover {
                                    background-color: #2980b9;
                                }
                                QPushButton:pressed {
                                    background-color: #21618c;
                                }
                            """)
                        elif value == 2:
                            btn.setText("🔬 详细Debug")
                            btn.setStyleSheet("""
                                QPushButton {
                                    background-color: #9b59b6;
                                    color: white;
                                    border: none;
                                    padding: 8px 16px;
                                    border-radius: 4px;
                                    font-size: 12px;
                                    font-weight: bold;
                                }
                                QPushButton:hover {
                                    background-color: #8e44ad;
                                }
                                QPushButton:pressed {
                                    background-color: #7d3c98;
                                }
                            """)
                    return update_style
                
                # 点击时循环切换值
                def make_toggle_debug_mode(btn, update_func):
                    def toggle():
                        # 循环：0→1→2→0
                        btn.current_value = (btn.current_value + 1) % 3
                        update_func(btn.current_value)
                        # 触发配置变化信号
                        self.on_config_changed()
                    return toggle
                
                # 连接信号
                update_func = make_update_debug_button_style(widget)
                widget.clicked.connect(make_toggle_debug_mode(widget, update_func))
                # 初始化样式
                update_func(int_value)
            elif param_type == 'int':
                widget = NoWheelSpinBox()
                # 取消数值范围限制，允许用户自由输入
                widget.setMinimum(-2147483648)  # 32位整数最小值
                widget.setMaximum(2147483647)   # 32位整数最大值
                # 确保default_value是整数类型
                try:
                    int_value = int(default_value)
                    widget.setValue(int_value)
                except (ValueError, TypeError):
                    # 如果转换失败，使用参数配置中的默认值
                    fallback_default = param_config.get('default', 0)
                    widget.setValue(int(fallback_default))
                widget.setStyleSheet("""
                    QSpinBox {
                        padding: 5px;
                        border: 1px solid #bdc3c7;
                        border-radius: 3px;
                        font-size: 12px;
                    }
                    QSpinBox:focus {
                        border-color: #3498db;
                    }
                """)
            elif param_type == 'float':
                widget = NoWheelDoubleSpinBox()
                # 取消数值范围限制，允许用户自由输入
                widget.setMinimum(-999999999.9)  # 极大负数
                widget.setMaximum(999999999.9)   # 极大正数
                widget.setSingleStep(param_config.get('step', 0.1))
                widget.setDecimals(3)  # 增加小数位数到3位，支持更精确的延迟设置
                # 确保default_value是浮点数类型
                try:
                    float_value = float(default_value)
                    widget.setValue(float_value)
                except (ValueError, TypeError):
                    # 如果转换失败，使用参数配置中的默认值
                    fallback_default = param_config.get('default', 0.0)
                    widget.setValue(float(fallback_default))
                widget.setStyleSheet("""
                    QDoubleSpinBox {
                        padding: 5px;
                        border: 1px solid #bdc3c7;
                        border-radius: 3px;
                        font-size: 12px;
                    }
                    QDoubleSpinBox:focus {
                        border-color: #3498db;
                    }
                """)
            elif param_type == 'str':
                widget = QLineEdit()
                # 设置字符串值
                str_value = str(default_value) if default_value is not None else param_config.get('default', '')
                widget.setText(str_value)
                widget.setStyleSheet("""
                    QLineEdit {
                        padding: 5px;
                        border: 1px solid #bdc3c7;
                        border-radius: 3px;
                        font-size: 12px;
                    }
                    QLineEdit:focus {
                        border-color: #3498db;
                    }
                """)
            elif param_type == 'bool':
                # 使用按钮形式的布尔控件
                widget = QPushButton()
                # 设置初始值
                bool_value = bool(default_value) if default_value is not None else param_config.get('default', False)
                widget.setCheckable(True)  # 设置为可切换按钮
                widget.setChecked(bool_value)
                
                # 更新按钮文本和样式（使用lambda捕获当前widget）
                def make_update_button_style(btn):
                    def update_style(checked):
                        if checked:
                            btn.setText("✓ 已启用")
                            btn.setStyleSheet("""
                                QPushButton {
                                    background-color: #27ae60;
                                    color: white;
                                    border: none;
                                    padding: 8px 16px;
                                    border-radius: 4px;
                                    font-size: 12px;
                                    font-weight: bold;
                                }
                                QPushButton:hover {
                                    background-color: #229954;
                                }
                                QPushButton:pressed {
                                    background-color: #1e8449;
                                }
                            """)
                        else:
                            btn.setText("✗ 已禁用")
                            btn.setStyleSheet("""
                                QPushButton {
                                    background-color: #e74c3c;
                                    color: white;
                                    border: none;
                                    padding: 8px 16px;
                                    border-radius: 4px;
                                    font-size: 12px;
                                    font-weight: bold;
                                }
                                QPushButton:hover {
                                    background-color: #c0392b;
                                }
                                QPushButton:pressed {
                                    background-color: #a93226;
                                }
                            """)
                    return update_style
                
                # 连接信号
                update_func = make_update_button_style(widget)
                widget.toggled.connect(update_func)
                # 初始化样式
                update_func(bool_value)
            else:
                # 默认使用整数控件
                widget = NoWheelSpinBox()
                # 设置数值范围（如果配置中有指定）
                min_value = param_config.get('min', -2147483648)
                max_value = param_config.get('max', 2147483647)
                widget.setMinimum(min_value)
                widget.setMaximum(max_value)
                # 确保default_value是整数类型
                try:
                    int_value = int(default_value)
                    widget.setValue(int_value)
                except (ValueError, TypeError):
                    # 如果转换失败，使用参数配置中的默认值
                    fallback_default = param_config.get('default', 0)
                    widget.setValue(int(fallback_default))
            
            # 存储控件引用
            self.config_widgets[behavior['id']][param_name] = widget
            
            # 连接值变化信号，实现自动保存
            if isinstance(widget, QSpinBox):
                widget.valueChanged.connect(self.on_config_changed)
            elif isinstance(widget, QDoubleSpinBox):
                widget.valueChanged.connect(self.on_config_changed)
            elif isinstance(widget, QLineEdit):
                widget.textChanged.connect(self.on_config_changed)
            elif isinstance(widget, QPushButton) and widget.isCheckable():
                widget.toggled.connect(self.on_config_changed)
            
            # 创建描述标签
            if description:
                desc_label = QLabel(f"({description})")
                desc_label.setStyleSheet("color: #7f8c8d; font-size: 10px; font-style: italic;")
                desc_label.setWordWrap(True)
                
                # 创建垂直布局包含控件和描述
                widget_container = QWidget()
                widget_layout = QVBoxLayout(widget_container)
                widget_layout.setContentsMargins(0, 0, 0, 0)
                widget_layout.setSpacing(2)
                widget_layout.addWidget(widget)
                widget_layout.addWidget(desc_label)
                
                form_layout.addRow(label, widget_container)
            else:
                form_layout.addRow(label, widget)
        
        scroll_area.setWidget(config_widget)
        return scroll_area
    
    def get_behavior_config(self, behavior_id):
        """获取行为的当前配置"""
        config = {}
        
        if behavior_id in self.config_widgets:
            for param_name, widget in self.config_widgets[behavior_id].items():
                if isinstance(widget, QSpinBox):
                    config[param_name] = widget.value()
                elif isinstance(widget, QDoubleSpinBox):
                    config[param_name] = widget.value()
                elif isinstance(widget, QLineEdit):
                    config[param_name] = widget.text()
                elif isinstance(widget, QPushButton):
                    if widget.isCheckable():
                        config[param_name] = widget.isChecked()
                    elif hasattr(widget, 'current_value'):
                        # debug_mode 循环按钮
                        config[param_name] = widget.current_value
        
        return config
    
    def load_configs(self):
        """加载保存的配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    configs = json.load(f)
                    print(f"✅ 加载配置成功，包含 {len(configs)} 个行为的配置")
                    return configs
            else:
                print("📄 配置文件不存在，使用默认配置")
                return {}
        except Exception as e:
            print(f"⚠️ 加载配置失败: {e}")
            return {}
    
    def save_configs(self):
        """保存当前配置"""
        try:
            # 先加载现有配置，保留未在UI中显示的行为配置
            existing_configs = {}
            if os.path.exists(self.config_file):
                try:
                    with open(self.config_file, 'r', encoding='utf-8') as f:
                        existing_configs = json.load(f)
                except:
                    existing_configs = {}
            
            # 收集所有行为的当前配置
            for behavior_id, widgets in self.config_widgets.items():
                behavior_config = {}
                for param_name, widget in widgets.items():
                    if isinstance(widget, QSpinBox):
                        behavior_config[param_name] = widget.value()
                    elif isinstance(widget, QDoubleSpinBox):
                        behavior_config[param_name] = widget.value()
                    elif isinstance(widget, QLineEdit):
                        behavior_config[param_name] = widget.text()
                    elif isinstance(widget, QPushButton):
                        if widget.isCheckable():
                            behavior_config[param_name] = widget.isChecked()
                        elif hasattr(widget, 'current_value'):
                            # debug_mode 循环按钮
                            behavior_config[param_name] = widget.current_value
                
                if behavior_config:  # 只保存非空配置
                    existing_configs[behavior_id] = behavior_config
            
            # 保存到文件
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(existing_configs, f, indent=2, ensure_ascii=False)
            
            print(f"💾 配置保存成功，包含 {len(existing_configs)} 个行为的配置")
            return True
            
        except Exception as e:
            print(f"⚠️ 保存配置失败: {e}")
            return False
    
    def apply_saved_config(self, behavior_id):
        """应用保存的配置到控件"""
        if behavior_id in self.saved_configs and behavior_id in self.config_widgets:
            saved_config = self.saved_configs[behavior_id]
            widgets = self.config_widgets[behavior_id]
            
            applied_count = 0
            for param_name, saved_value in saved_config.items():
                if param_name in widgets:
                    widget = widgets[param_name]
                    try:
                        if isinstance(widget, QSpinBox):
                            # 整数控件需要转换为int
                            int_value = int(saved_value)
                            widget.setValue(int_value)
                            applied_count += 1
                        elif isinstance(widget, QDoubleSpinBox):
                            # 浮点数控件需要转换为float
                            float_value = float(saved_value)
                            widget.setValue(float_value)
                            applied_count += 1
                        elif isinstance(widget, QLineEdit):
                            # 字符串控件直接设置文本
                            str_value = str(saved_value)
                            widget.setText(str_value)
                            applied_count += 1
                        elif isinstance(widget, QPushButton):
                            if widget.isCheckable():
                                # 布尔按钮控件需要转换为bool
                                # 正确处理字符串 "True"/"False" 和布尔值
                                if isinstance(saved_value, bool):
                                    bool_value = saved_value
                                elif isinstance(saved_value, str):
                                    bool_value = saved_value.lower() in ('true', '1', 'yes')
                                else:
                                    bool_value = bool(saved_value)
                                widget.setChecked(bool_value)
                                applied_count += 1
                            elif hasattr(widget, 'current_value'):
                                # debug_mode 循环按钮（0→1→2→0）
                                int_value = int(saved_value)
                                int_value = max(0, min(2, int_value))  # 确保在 0-2 范围内
                                widget.current_value = int_value
                                # 查找更新函数并调用
                                # 需要触发样式更新
                                if int_value == 0:
                                    widget.setText("✗ 关闭")
                                    widget.setStyleSheet("""
                                        QPushButton {
                                            background-color: #95a5a6;
                                            color: white;
                                            border: none;
                                            padding: 8px 16px;
                                            border-radius: 4px;
                                            font-size: 12px;
                                            font-weight: bold;
                                        }
                                        QPushButton:hover { background-color: #7f8c8d; }
                                        QPushButton:pressed { background-color: #707b7c; }
                                    """)
                                elif int_value == 1:
                                    widget.setText("🔍 简化Debug")
                                    widget.setStyleSheet("""
                                        QPushButton {
                                            background-color: #3498db;
                                            color: white;
                                            border: none;
                                            padding: 8px 16px;
                                            border-radius: 4px;
                                            font-size: 12px;
                                            font-weight: bold;
                                        }
                                        QPushButton:hover { background-color: #2980b9; }
                                        QPushButton:pressed { background-color: #21618c; }
                                    """)
                                elif int_value == 2:
                                    widget.setText("🔬 详细Debug")
                                    widget.setStyleSheet("""
                                        QPushButton {
                                            background-color: #9b59b6;
                                            color: white;
                                            border: none;
                                            padding: 8px 16px;
                                            border-radius: 4px;
                                            font-size: 12px;
                                            font-weight: bold;
                                        }
                                        QPushButton:hover { background-color: #8e44ad; }
                                        QPushButton:pressed { background-color: #7d3c98; }
                                    """)
                                applied_count += 1
                    except (ValueError, TypeError, Exception) as e:
                        print(f"⚠️ 应用配置 {param_name}={saved_value} 失败: {e}")
            
            if applied_count > 0:
                print(f"🔧 为行为 {behavior_id} 应用了 {applied_count} 个保存的配置")
    
    def on_config_changed(self):
        """配置变化时自动保存"""
        try:
            # 延迟保存，避免频繁写入
            if hasattr(self, '_save_timer'):
                self._save_timer.stop()
            
            self._save_timer = QTimer()
            self._save_timer.setSingleShot(True)
            self._save_timer.timeout.connect(self.save_configs)
            self._save_timer.start(1000)  # 1秒后保存
            
        except Exception as e:
            print(f"⚠️ 配置变化处理失败: {e}")
    
    def closeEvent(self, event):
        """窗口关闭时保存配置"""
        try:
            self.save_configs()
            print("👋 程序退出，配置已保存")
        except Exception as e:
            print(f"⚠️ 退出时保存配置失败: {e}")
        
        # 停止行为（如果正在运行）
        if hasattr(self, 'current_behavior') and self.current_behavior:
            try:
                self.current_behavior.stop()
            except:
                pass
        
        event.accept()
        
    def select_action(self, action_id):
        """选择具体的行为"""
        self.current_action = action_id
        
        # 动态查找行为对应的页面索引
        behavior_list = self.behavior_manager.get_behavior_list()
        
        # 页面索引：0是选择页面，1开始是详细页面
        for i, behavior in enumerate(behavior_list):
            if behavior['id'] == action_id:
                page_index = i + 1  # +1 因为索引0是选择页面
                self.action_stacked.setCurrentIndex(page_index)
                break
            
    def execute_action(self, action_id):
        """执行具体的行为"""
        # 切换到日志页面以便查看执行过程
        self.switch_page("log")
        
        # 清空日志
        self.log_text.clear()
        self.log_text.append(f"🎯 准备执行行为: {action_id}")
        
        # 使用behavior模块执行
        self.start_behavior(action_id)
        
    def create_main_page(self):
        """创建主页"""
        main_page = QWidget()
        layout = QVBoxLayout(main_page)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 页面标题
        title = QLabel("主控制面板")
        title.setFont(QFont("", 18, QFont.Bold))
        layout.addWidget(title)
        
        # 控制区域
        control_frame = QFrame()
        control_frame.setFrameStyle(QFrame.Box)
        control_layout = QVBoxLayout(control_frame)
        
        # 基础按钮
        self.start_button = QPushButton("启动程序")
        self.start_button.setMinimumHeight(50)
        self.start_button.setStyleSheet("QPushButton { font-size: 14px; background-color: #27ae60; color: white; }")
        self.start_button.clicked.connect(self.on_start_clicked)
        control_layout.addWidget(self.start_button)
        
        self.stop_button = QPushButton("停止程序")
        self.stop_button.setMinimumHeight(50)
        self.stop_button.setEnabled(False)
        self.stop_button.setStyleSheet("QPushButton { font-size: 14px; background-color: #e74c3c; color: white; }")
        self.stop_button.clicked.connect(self.on_stop_clicked)
        control_layout.addWidget(self.stop_button)
        
        # 状态显示
        status_frame = QFrame()
        status_frame.setFrameStyle(QFrame.Box)
        status_layout = QVBoxLayout(status_frame)
        
        status_label = QLabel("程序状态:")
        status_label.setFont(QFont("", 12, QFont.Bold))
        status_layout.addWidget(status_label)
        
        self.status_display = QLabel("未启动")
        self.status_display.setStyleSheet("QLabel { color: red; font-weight: bold; font-size: 16px; }")
        status_layout.addWidget(self.status_display)
        
        layout.addWidget(control_frame)
        layout.addWidget(status_frame)
        layout.addStretch()
        
        self.stacked_widget.addWidget(main_page)
        
    def create_process_page(self):
        """创建进程监控页面"""
        process_page = QWidget()
        layout = QVBoxLayout(process_page)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 页面标题
        title = QLabel("进程监控")
        title.setFont(QFont("", 18, QFont.Bold))
        layout.addWidget(title)
        
        # 进程信息容器
        self.process_container = QWidget()
        process_layout = QVBoxLayout(self.process_container)
        
        # 无进程时的提示
        self.no_process_label = QLabel("未检测到 DeltaForce 进程")
        self.no_process_label.setAlignment(Qt.AlignCenter)
        self.no_process_label.setStyleSheet("color: gray; font-size: 14px; padding: 50px;")
        process_layout.addWidget(self.no_process_label)
        
        layout.addWidget(self.process_container)
        layout.addStretch()
        
        self.stacked_widget.addWidget(process_page)
    
    def create_task_history_page(self):
        """创建执行记录页面"""
        from PySide6.QtWidgets import QScrollArea, QFrame
        
        history_page = QWidget()
        layout = QVBoxLayout(history_page)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 页面标题
        title = QLabel("执行记录")
        title.setFont(QFont("", 18, QFont.Bold))
        layout.addWidget(title)
        
        # 控制按钮区域
        control_layout = QHBoxLayout()
        
        # 刷新按钮
        refresh_btn = QPushButton("🔄 刷新")
        refresh_btn.clicked.connect(self.refresh_task_history)
        control_layout.addWidget(refresh_btn)
        
        # 清理按钮
        clear_btn = QPushButton("🗑️ 清理旧记录")
        clear_btn.clicked.connect(self.clear_old_task_records)
        control_layout.addWidget(clear_btn)
        
        control_layout.addStretch()
        layout.addLayout(control_layout)
        
        # 创建执行记录页面的堆叠窗口
        self.history_stacked = QStackedWidget()
        
        # 创建任务列表页面
        list_page = QWidget()
        list_layout = QVBoxLayout(list_page)
        list_layout.setContentsMargins(0, 0, 0, 0)
        
        # 创建滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        
        # 创建容器widget
        self.task_history_container = QWidget()
        self.task_history_layout = QVBoxLayout(self.task_history_container)
        self.task_history_layout.setSpacing(15)
        self.task_history_layout.setContentsMargins(10, 10, 10, 10)
        
        scroll_area.setWidget(self.task_history_container)
        list_layout.addWidget(scroll_area)
        
        # 统计信息
        self.history_stats_label = QLabel("统计信息将在此显示")
        self.history_stats_label.setStyleSheet("padding: 10px; background-color: #f0f0f0; border-radius: 5px;")
        list_layout.addWidget(self.history_stats_label)
        
        self.history_stacked.addWidget(list_page)
        
        # 创建任务详情页面
        self.create_task_detail_page()
        
        layout.addWidget(self.history_stacked)
        
        self.stacked_widget.addWidget(history_page)
        
        # 初始加载数据
        self.refresh_task_history()
    
    def create_task_detail_page(self):
        """创建任务详情页面"""
        detail_page = QWidget()
        layout = QVBoxLayout(detail_page)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 顶部导航区域
        nav_layout = QHBoxLayout()
        
        # 返回按钮
        back_btn = QPushButton("← 返回列表")
        back_btn.clicked.connect(lambda: self.history_stacked.setCurrentIndex(0))
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: #007acc;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #005a9e;
            }
        """)
        nav_layout.addWidget(back_btn)
        
        # 任务标题
        self.detail_title_label = QLabel("任务详情")
        self.detail_title_label.setFont(QFont("", 16, QFont.Bold))
        nav_layout.addWidget(self.detail_title_label)
        
        nav_layout.addStretch()
        layout.addLayout(nav_layout)
        
        # 创建日志样式的文本显示区域
        self.task_detail_text = QTextEdit()
        self.task_detail_text.setReadOnly(True)
        self.task_detail_text.setFont(QFont("Consolas", 10))
        self.task_detail_text.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #ffffff;
                border: 1px solid #333;
                border-radius: 4px;
                padding: 10px;
                font-family: 'Consolas', 'Monaco', monospace;
            }
        """)
        layout.addWidget(self.task_detail_text)
        
        self.history_stacked.addWidget(detail_page)
    
    def refresh_task_history(self):
        """刷新执行记录"""
        try:
            from task_logger import get_task_logger
            from datetime import datetime
            
            task_logger = get_task_logger()
            tasks = task_logger.get_recent_tasks(20)
            
            # 清空现有卡片
            for i in reversed(range(self.task_history_layout.count())):
                child = self.task_history_layout.itemAt(i).widget()
                if child:
                    child.setParent(None)
            
            # 创建任务卡片
            for task in tasks:
                card = self.create_task_card(task)
                self.task_history_layout.addWidget(card)
            
            # 添加弹性空间
            self.task_history_layout.addStretch()
            
            # 更新统计信息
            self.update_history_statistics()
            
        except Exception as e:
            self.history_stats_label.setText(f"❌ 加载执行记录失败: {e}")
    
    def create_task_card(self, task):
        """创建任务卡片"""
        from PySide6.QtWidgets import QFrame
        from datetime import datetime
        
        # 创建卡片容器
        card = QFrame()
        card.setFrameStyle(QFrame.Box)
        card.setStyleSheet("""
            QFrame {
                background-color: white;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 10px;
            }
            QFrame:hover {
                border-color: #007acc;
                background-color: #f8f9fa;
            }
        """)
        card.setFixedHeight(120)
        card.setCursor(Qt.PointingHandCursor)
        
        layout = QVBoxLayout(card)
        layout.setContentsMargins(15, 10, 15, 10)
        layout.setSpacing(5)
        
        # 解析数据
        script_id = task.get('script_id', 'UNKNOWN')
        start_time = task.get('start_time', '')
        duration = task.get('duration', 0)
        status = task.get('status', 'unknown')
        
        # 格式化时间
        if start_time:
            try:
                dt = datetime.fromisoformat(start_time)
                time_str = dt.strftime("%m-%d %H:%M:%S")
            except:
                time_str = start_time[:16] if len(start_time) > 16 else start_time
        else:
            time_str = "未知时间"
        
        # 格式化时长
        if duration > 3600:
            duration_str = f"{duration/3600:.1f}小时"
        elif duration > 60:
            duration_str = f"{duration/60:.1f}分钟"
        else:
            duration_str = f"{duration:.1f}秒"
        
        # 标题行：时间 + 行为ID
        title_layout = QHBoxLayout()
        title_label = QLabel(f"{time_str} - {script_id}")
        title_label.setFont(QFont("", 12, QFont.Bold))
        title_layout.addWidget(title_label)
        
        # 状态标签
        status_label = QLabel(status)
        status_label.setFont(QFont("", 10))
        if status == 'completed':
            status_label.setStyleSheet("color: green; background-color: #e8f5e8; padding: 2px 6px; border-radius: 3px;")
        elif status == 'interrupted':
            status_label.setStyleSheet("color: orange; background-color: #fff3cd; padding: 2px 6px; border-radius: 3px;")
        else:
            status_label.setStyleSheet("color: red; background-color: #f8d7da; padding: 2px 6px; border-radius: 3px;")
        title_layout.addWidget(status_label)
        
        layout.addLayout(title_layout)
        
        # 摘要统计数据 - 适应新的LogManager结构
        statistics = task.get('statistics', {})
        summary_parts = []
        
        # 日志统计
        message_count = statistics.get('message_count', 0)
        if message_count > 0:
            summary_parts.append(f"日志: {message_count}条")
        
        # 业务统计 - 新的LogManager会将这些数据放在statistics根级别
        if statistics.get('refresh_count', 0) > 0:
            summary_parts.append(f"刷新: {statistics['refresh_count']}")
        if statistics.get('purchase_count', 0) > 0:
            summary_parts.append(f"购买: {statistics['purchase_count']}")
        if statistics.get('low_price_found_count', 0) > 0:
            summary_parts.append(f"低价: {statistics['low_price_found_count']}")
        
        # 余额变化
        initial_balance = statistics.get('initial_balance')
        current_balance = statistics.get('current_balance')
        if initial_balance and current_balance:
            balance_change = current_balance - initial_balance
            if balance_change != 0:
                summary_parts.append(f"余额变化: {balance_change:+,.0f}")
        total_cost = statistics.get('total_cost', 0)
        if total_cost and isinstance(total_cost, (int, float)) and total_cost != 0:
            summary_parts.append(f"花费: {total_cost:,}")
        
        summary_parts.append(f"时长: {duration_str}")
        
        summary_text = " | ".join(summary_parts) if summary_parts else "无统计数据"
        
        summary_label = QLabel(summary_text)
        summary_label.setFont(QFont("", 10))
        summary_label.setStyleSheet("color: #666;")
        summary_label.setWordWrap(True)
        layout.addWidget(summary_label)
        
        # 点击事件 - 跳转到详情页面
        card.mousePressEvent = lambda event: self.show_task_detail_page(task)
        
        return card
    
    def show_task_detail_page(self, task):
        """显示任务详情页面"""
        # 更新详情页面内容
        self.update_task_detail_content(task)
        
        # 切换到详情页面
        self.history_stacked.setCurrentIndex(1)
    
    def update_task_detail_content(self, task):
        """更新任务详情内容"""
        # 更新标题
        task_id = task.get('task_id', '未知任务')
        self.detail_title_label.setText(f"任务详情 - {task_id}")
        
        # 构建详情内容
        details = self.build_task_detail_text(task)
        
        # 设置到文本区域
        self.task_detail_text.setPlainText(details)
        
        # 滚动到顶部
        cursor = self.task_detail_text.textCursor()
        cursor.movePosition(cursor.MoveOperation.Start)
        self.task_detail_text.setTextCursor(cursor)
    
    def build_task_detail_text(self, task):
        """构建任务详情文本"""
        details = []
        
        # 基本信息
        details.append("=" * 80)
        details.append("📋 任务基本信息")
        details.append("=" * 80)
        details.append(f"任务ID: {task.get('task_id', '未知')}")
        details.append(f"脚本ID: {task.get('script_id', '未知')}")
        details.append(f"开始时间: {task.get('start_time', '未知')}")
        details.append(f"结束时间: {task.get('end_time', '未知')}")
        details.append(f"运行时长: {task.get('duration', 0):.1f}秒")
        details.append(f"状态: {task.get('status', '未知')}")
        details.append("")
        
        # 摘要信息 - 紧跟在基本信息后面
        summary = task.get('summary', '')
        if summary:
            details.append("=" * 80)
            details.append("📝 执行摘要")
            details.append("=" * 80)
            details.append(summary)
            details.append("")
        
        # 统计数据
        statistics = task.get('statistics', {})
        if statistics:
            details.append("=" * 80)
            details.append("📊 统计数据")
            details.append("=" * 80)
            
            # 日志统计
            message_count = statistics.get('message_count', 0)
            if message_count > 0:
                details.append("📝 日志统计:")
                details.append(f"  总日志数: {message_count}")
                details.append(f"  成功日志: {statistics.get('success_count', 0)}")
                details.append(f"  警告日志: {statistics.get('warning_count', 0)}")
                details.append(f"  错误日志: {statistics.get('error_count', 0)}")
                details.append(f"  信息日志: {statistics.get('info_count', 0)}")
                details.append(f"  调试日志: {statistics.get('debug_count', 0)}")
                details.append("")
            
            # 业务统计
            details.append("📈 业务统计:")
            refresh_count = statistics.get('refresh_count', 0)
            if refresh_count > 0:
                details.append(f"  刷新次数: {refresh_count}")
            
            purchase_count = statistics.get('purchase_count', 0)
            if purchase_count > 0:
                details.append(f"  购买次数: {purchase_count}")
            
            # 余额信息
            initial_balance = statistics.get('initial_balance')
            current_balance = statistics.get('current_balance')
            if initial_balance is not None and isinstance(initial_balance, (int, float)):
                details.append(f"  初始余额: {initial_balance:,}")
            if current_balance is not None and isinstance(current_balance, (int, float)):
                details.append(f"  最终余额: {current_balance:,}")
                if initial_balance is not None:
                    balance_change = current_balance - initial_balance
                    details.append(f"  余额变化: {balance_change:+,}")
            
            # 其他业务数据
            target_price = statistics.get('target_price')
            if target_price is not None:
                details.append(f"  目标价格: {target_price}")
            
            unit_price = statistics.get('unit_price')
            if unit_price is not None:
                details.append(f"  最后单价: {unit_price:.1f}")
            
            details.append("")
        
        # 详细日志记录 - 放在最下面
        detailed_logs = task.get('detailed_logs', [])
        details.append("=" * 80)
        details.append("📋 详细日志记录")
        details.append("=" * 80)
        
        if detailed_logs:
            details.append(f"共 {len(detailed_logs)} 条日志记录:")
            details.append("")
            
            for i, log_entry in enumerate(detailed_logs, 1):
                timestamp = log_entry.get('timestamp', '')
                level = log_entry.get('level', 'INFO')
                message = log_entry.get('message', '')
                
                # 根据日志级别设置前缀
                level_prefix = {
                    'DEBUG': '🔍',
                    'INFO': 'ℹ️',
                    'WARNING': '⚠️',
                    'ERROR': '❌',
                    'SUCCESS': '✅'
                }.get(level, '📝')
                
                details.append(f"{i:3d}. [{timestamp}] {level_prefix} {message}")
                
                # 如果有额外的统计数据，也显示出来
                kwargs = log_entry.get('kwargs', {})
                if kwargs:
                    for key, value in kwargs.items():
                        details.append(f"     └─ {key}: {value}")
        else:
            details.append("暂无详细日志记录")
        
        return "\n".join(details)
    
    def show_task_details(self, task):
        """显示任务详细信息"""
        from PySide6.QtWidgets import QDialog, QTextEdit, QDialogButtonBox
        from datetime import datetime
        
        dialog = QDialog(self)
        dialog.setWindowTitle("任务详细信息")
        dialog.setMinimumSize(600, 500)
        
        layout = QVBoxLayout(dialog)
        
        # 创建文本显示区域
        text_edit = QTextEdit()
        text_edit.setReadOnly(True)
        text_edit.setFont(QFont("Consolas", 10))
        
        # 构建详细信息文本
        details = []
        
        # 基本信息
        details.append("=" * 60)
        details.append("📋 任务基本信息")
        details.append("=" * 60)
        details.append(f"任务ID: {task.get('task_id', '未知')}")
        details.append(f"脚本ID: {task.get('script_id', '未知')}")
        details.append(f"开始时间: {task.get('start_time', '未知')}")
        details.append(f"结束时间: {task.get('end_time', '未知')}")
        details.append(f"运行时长: {task.get('duration', 0):.1f}秒")
        details.append(f"状态: {task.get('status', '未知')}")
        details.append("")
        
        # 统计数据 - 适应新的LogManager结构
        statistics = task.get('statistics', {})
        if statistics:
            details.append("=" * 60)
            details.append("📊 统计数据")
            details.append("=" * 60)
            
            # 日志统计
            message_count = statistics.get('message_count', 0)
            if message_count > 0:
                details.append(f"📝 日志统计:")
                details.append(f"  总日志数: {message_count}")
                details.append(f"  成功日志: {statistics.get('success_count', 0)}")
                details.append(f"  警告日志: {statistics.get('warning_count', 0)}")
                details.append(f"  错误日志: {statistics.get('error_count', 0)}")
                details.append(f"  信息日志: {statistics.get('info_count', 0)}")
                details.append(f"  调试日志: {statistics.get('debug_count', 0)}")
                details.append("")
            
            # 业务统计
            details.append("📈 业务统计:")
            refresh_count = statistics.get('refresh_count', 0)
            if refresh_count > 0:
                details.append(f"  刷新次数: {refresh_count}")
            
            purchase_count = statistics.get('purchase_count', 0)
            if purchase_count > 0:
                details.append(f"  购买次数: {purchase_count}")
            
            low_price_count = statistics.get('low_price_found_count', 0)
            if low_price_count > 0:
                details.append(f"  发现低价次数: {low_price_count}")
            
            # 余额信息
            initial_balance = statistics.get('initial_balance')
            current_balance = statistics.get('current_balance')  # 新LogManager使用current_balance
            if initial_balance is not None and isinstance(initial_balance, (int, float)):
                details.append(f"  初始余额: {initial_balance:,}")
            if current_balance is not None and isinstance(current_balance, (int, float)):
                details.append(f"  最终余额: {current_balance:,}")
                if initial_balance is not None:
                    balance_change = current_balance - initial_balance
                    details.append(f"  余额变化: {balance_change:+,}")
            
            # 其他业务数据
            target_price = statistics.get('target_price')
            if target_price is not None:
                details.append(f"  目标价格: {target_price}")
            
            unit_price = statistics.get('unit_price')
            if unit_price is not None:
                details.append(f"  最后单价: {unit_price:.1f}")
            
            purchased_quantity = statistics.get('purchased_quantity')
            if purchased_quantity is not None:
                details.append(f"  购买数量: {purchased_quantity:.0f}发")
            
            # 花费信息
            refresh_cost = statistics.get('refresh_cost')
            if refresh_cost is not None and isinstance(refresh_cost, (int, float)):
                details.append(f"  刷新花费: {refresh_cost:,}")
            
            purchase_cost = statistics.get('purchase_cost')
            if purchase_cost is not None and isinstance(purchase_cost, (int, float)):
                details.append(f"  购买花费: {purchase_cost:,}")
            
            # 显示所有其他统计数据
            details.append("")
            details.append("🔍 其他统计数据:")
            for key, value in statistics.items():
                if key not in ['message_count', 'success_count', 'warning_count', 'error_count', 
                              'info_count', 'debug_count', 'refresh_count', 'purchase_count', 
                              'initial_balance', 'current_balance', 'target_price', 'unit_price', 
                              'purchased_quantity', 'refresh_cost', 'purchase_cost']:
                    if isinstance(value, (int, float)):
                        if isinstance(value, float):
                            details.append(f"  {key}: {value:,.2f}")
                        else:
                            details.append(f"  {key}: {value:,}")
                    else:
                        details.append(f"  {key}: {value}")
            
            # 效率信息
            refresh_efficiency = statistics.get('refresh_efficiency')
            if refresh_efficiency is not None and isinstance(refresh_efficiency, (int, float)):
                details.append(f"发现低价效率: {refresh_efficiency:.1f}%")
            
            # 配置信息
            details.append(f"目标价格: {statistics.get('target_price', '未知')}")
            details.append(f"最低价格阈值: {statistics.get('min_price_threshold', '未知')}")
            details.append(f"工作时间范围: {statistics.get('work_time_range', '未知')}")
            details.append("")
        
        # 摘要
        summary = task.get('summary', '')
        if summary:
            details.append("=" * 60)
            details.append("📝 执行摘要")
            details.append("=" * 60)
            details.append(summary)
        
        text_edit.setPlainText("\n".join(details))
        layout.addWidget(text_edit)
        
        # 按钮
        button_box = QDialogButtonBox(QDialogButtonBox.Ok)
        button_box.accepted.connect(dialog.accept)
        layout.addWidget(button_box)
        
        dialog.exec()
    
    def update_history_statistics(self):
        """更新统计信息"""
        try:
            from task_logger import get_task_logger
            
            task_logger = get_task_logger()
            stats = task_logger.get_statistics_summary()
            
            total_tasks = stats.get('total_tasks', 0)
            scripts_stats = stats.get('scripts', {})
            
            stats_text = f"📊 总任务数: {total_tasks}"
            
            for script_id, script_stats in scripts_stats.items():
                count = script_stats.get('count', 0)
                success_count = script_stats.get('success_count', 0)
                success_rate = (success_count / count * 100) if count > 0 else 0
                avg_duration = script_stats.get('total_duration', 0) / count if count > 0 else 0
                
                stats_text += f" | {script_id}: {count}次 (成功率: {success_rate:.1f}%, 平均时长: {avg_duration:.1f}秒)"
            
            self.history_stats_label.setText(stats_text)
            
        except Exception as e:
            self.history_stats_label.setText(f"❌ 统计信息更新失败: {e}")
    
    def clear_old_task_records(self):
        """清理旧的任务记录"""
        try:
            from PySide6.QtWidgets import QMessageBox
            from task_logger import get_task_logger
            
            reply = QMessageBox.question(
                self, 
                "确认清理", 
                "是否清理30天前的任务记录？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                task_logger = get_task_logger()
                cleared_count = task_logger.clear_old_records(30)
                
                QMessageBox.information(
                    self,
                    "清理完成",
                    f"已清理 {cleared_count} 条旧记录"
                )
                
                # 刷新显示
                self.refresh_task_history()
                
        except Exception as e:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "错误", f"清理失败: {e}")
    
    def create_settings_page(self):
        """创建设置页面"""
        settings_page = QWidget()
        layout = QVBoxLayout(settings_page)
        layout.setContentsMargins(20, 20, 20, 20)
        
        title = QLabel("设置")
        title.setFont(QFont("", 18, QFont.Bold))
        layout.addWidget(title)
        
        # 设置内容（暂时为空）
        content = QLabel("设置功能正在开发中...")
        content.setAlignment(Qt.AlignCenter)
        content.setStyleSheet("color: gray; font-size: 14px;")
        layout.addWidget(content)
        
        layout.addStretch()
        self.stacked_widget.addWidget(settings_page)
        
    def create_log_page(self):
        """创建日志页面"""
        log_page = QWidget()
        layout = QVBoxLayout(log_page)
        layout.setContentsMargins(20, 20, 20, 20)
        
        title = QLabel("运行日志")
        title.setFont(QFont("", 18, QFont.Bold))
        layout.addWidget(title)
        
        # 日志文本框
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Consolas", 10))
        self.log_text.append("程序已启动，等待操作...")
        layout.addWidget(self.log_text)
        
        # 按钮区域
        button_layout = QHBoxLayout()
        
        # 停止脚本按钮
        self.stop_script_button = QPushButton("🛑 停止脚本")
        self.stop_script_button.setMaximumWidth(120)
        self.stop_script_button.setStyleSheet("QPushButton { background-color: #e74c3c; color: white; padding: 8px; border-radius: 5px; }")
        self.stop_script_button.clicked.connect(self.stop_current_script)
        button_layout.addWidget(self.stop_script_button)
        
        # 清除日志按钮
        clear_log_button = QPushButton("清除日志")
        clear_log_button.setMaximumWidth(100)
        clear_log_button.clicked.connect(self.clear_log)
        button_layout.addWidget(clear_log_button)
        
        button_layout.addStretch()
        layout.addLayout(button_layout)
        
        self.stacked_widget.addWidget(log_page)
        
    def create_about_page(self):
        """创建关于页面"""
        about_page = QWidget()
        layout = QVBoxLayout(about_page)
        layout.setContentsMargins(20, 20, 20, 20)
        
        title = QLabel("关于")
        title.setFont(QFont("", 18, QFont.Bold))
        layout.addWidget(title)
        
        # 关于内容
        # 从应用程序属性中读取版本号
        from PySide6.QtWidgets import QApplication
        app_version = QApplication.instance().applicationVersion()
        
        about_text = QLabel(f"""
        <h3>DeltaForce MarketBot v{app_version}</h3>
        <p>一个用于DeltaForce游戏的自动化交易工具</p>
        <br>
        <p><b>功能特性：</b></p>
        <ul>
        <li>自动价格监控</li>
        <li>智能交易决策</li>
        <li>实时日志记录</li>
        <li>用户友好界面</li>
        </ul>
        <br>
        <p>© 2025 WintryWind</p>
        """)
        about_text.setWordWrap(True)
        about_text.setAlignment(Qt.AlignTop)
        layout.addWidget(about_text)
        
        layout.addStretch()
        self.stacked_widget.addWidget(about_page)
        
    def refresh_all_content(self):
        """刷新所有内容"""
        try:
            self.status_bar.showMessage("正在刷新...")
            
            # 1. 重新加载行为管理器
            if hasattr(self, 'behavior_manager'):
                self.behavior_manager.load_behaviors()
                print("✅ 行为管理器已刷新")
            
            # 2. 重新创建行为选择页面
            if hasattr(self, 'action_stacked'):
                # 清除现有的行为页面
                while self.action_stacked.count() > 0:
                    widget = self.action_stacked.widget(0)
                    self.action_stacked.removeWidget(widget)
                    if widget:
                        widget.deleteLater()
                
                # 重新创建行为选择页面
                self.create_action_selection_page()
                
                # 重新创建行为详情页面
                self.create_action_detail_pages()
                
                print("✅ 行为页面已刷新")
            
            # 3. 重新加载配置
            self.saved_configs = self.load_configs()
            print("✅ 配置文件已重新加载")
            
            # 4. 清空配置控件缓存
            self.config_widgets.clear()
            print("✅ 配置控件缓存已清空")
            
            # 5. 如果当前在行为页面，刷新显示
            if self.current_page == "action":
                self.switch_page("action")
            
            self.status_bar.showMessage("刷新完成")
            print("🔄 所有内容已刷新完成")
            
        except Exception as e:
            self.status_bar.showMessage(f"刷新失败: {e}")
            print(f"❌ 刷新失败: {e}")
    
    def create_status_bar(self):
        """创建状态栏"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("就绪")
        
    def switch_page(self, page_name):
        """切换页面"""
        # 更新按钮状态
        for name, button in self.nav_buttons.items():
            if name == page_name:
                button.setProperty("selected", "true")
                button.setStyleSheet(button.styleSheet())  # 刷新样式
            else:
                button.setProperty("selected", "false")
                button.setStyleSheet(button.styleSheet())  # 刷新样式
        
        # 切换页面
        page_index = {"action": 0, "main": 1, "process": 2, "history": 3, "settings": 4, "log": 5, "about": 6}
        if page_name in page_index:
            self.stacked_widget.setCurrentIndex(page_index[page_name])
            self.current_page = page_name
            self.status_bar.showMessage(f"当前页面: {page_name}")
            
            # 如果切换到执行记录页面，自动刷新数据并显示列表页面
            if page_name == "history":
                self.history_stacked.setCurrentIndex(0)  # 显示列表页面
                self.refresh_task_history()
            
            # 如果切换到行为页面，重置到选择界面
            if page_name == "action":
                self.action_stacked.setCurrentIndex(0)
        
    def on_start_clicked(self):
        """启动按钮点击事件"""
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.status_display.setText("运行中")
        self.status_display.setStyleSheet("QLabel { color: green; font-weight: bold; }")
        self.status_bar.showMessage("程序运行中...")
        self.log_text.append("程序已启动")
        
    def on_stop_clicked(self):
        """停止按钮点击事件"""
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.status_display.setText("已停止")
        self.status_display.setStyleSheet("QLabel { color: red; font-weight: bold; }")
        self.status_bar.showMessage("程序已停止")
        self.log_text.append("程序已停止")
        
    def clear_log(self):
        """清除日志"""
        self.log_text.clear()
        self.log_text.append("日志已清除")
        
    def stop_current_script(self):
        """停止当前运行的脚本"""
        # 停止用户输入监控
        if self.input_monitor and self.input_monitor.isRunning():
            self.input_monitor.stop_monitoring()
            self.input_monitor.wait(1000)  # 等待1秒
            self.log_text.append("✅ 输入监控已停止")
        
        # 停止行为线程
        if self.current_behavior and self.current_behavior.isRunning():
            self.current_behavior.stop_behavior()
            self.current_behavior.wait(3000)  # 等待3秒
            self.log_text.append("✅ 行为线程已停止")
        
        # 只使用behavior模块，无需脚本管理器
    
    def start_behavior(self, behavior_id):
        """启动指定的行为"""
        try:
            # 检查是否有行为正在运行
            if self.current_behavior and self.current_behavior.isRunning():
                self.log_text.append("⚠️ 已有行为正在运行中")
                return
            
            # 获取DeltaForce窗口句柄（使用原有方法）
            processes = self.get_deltaforce_processes()
            window_handles = [process['hwnd'] for process in processes]
            
            if not window_handles:
                self.log_text.append("❌ 未找到DeltaForce窗口")
                return
            
            self.log_text.append(f"🎯 准备执行行为: {behavior_id}")
            self.log_text.append(f"📊 获取到 {len(window_handles)} 个窗口句柄: {window_handles}")
            
            # 获取自定义配置
            config = self.get_behavior_config(behavior_id)
            self.log_text.append(f"🎛️ 使用自定义配置: {config}")
            
            # 每次执行都从磁盘重新加载behavior模块，支持热更新
            try:
                # 动态导入behavior模块
                import importlib.util
                import os
                
                behavior_file = f"gui/behavior/{behavior_id}.py"
                if not os.path.exists(behavior_file):
                    self.log_text.append(f"❌ 行为文件不存在: {behavior_file}")
                    return
                
                self.log_text.append(f"🔄 从磁盘重新加载行为模块: {behavior_file}")
                
                # 重新加载模块
                spec = importlib.util.spec_from_file_location(behavior_id, behavior_file)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                
                # 获取behavior类
                if hasattr(module, 'get_behavior_class'):
                    behavior_class = module.get_behavior_class()
                else:
                    # 查找继承自Behavior的类
                    behavior_class = None
                    for name in dir(module):
                        obj = getattr(module, name)
                        if (isinstance(obj, type) and 
                            hasattr(obj, '__bases__') and
                            any('Behavior' in str(base) for base in obj.__bases__)):
                            behavior_class = obj
                            break
                
                if not behavior_class:
                    self.log_text.append(f"❌ 未找到有效的Behavior类: {behavior_id}")
                    return
                
                # 创建behavior实例
                self.current_behavior = behavior_class(window_handles, config)
                self.log_text.append(f"✅ 成功创建行为实例: {behavior_class.__name__} (热加载)")
                
            except Exception as e:
                self.log_text.append(f"❌ 创建行为实例失败: {behavior_id}, 错误: {e}")
                return
            
            # 连接行为信号
            if hasattr(self.current_behavior, 'log_message'):
                self.current_behavior.log_message.connect(self.log_text.append)
            if hasattr(self.current_behavior, 'status_changed'):
                self.current_behavior.status_changed.connect(self.on_behavior_status_changed)
            if hasattr(self.current_behavior, 'finished_signal'):
                self.current_behavior.finished_signal.connect(self.on_behavior_finished)
            
            # LogManager会自动处理任务记录
            
            # 启动行为（新的Behavior基类内置Q键监听和分层线程管理）
            self.current_behavior.start()
            
            # 获取行为标题
            behavior_title = behavior_id
            if hasattr(module, 'BEHAVIOR_INFO'):
                behavior_title = module.BEHAVIOR_INFO.get('title', behavior_id)
            
            self.log_text.append(f"🚀 {behavior_title} 已启动")
            self.log_text.append("🎯 分层线程架构已激活 (Q键监听 + 日志线程 + 主逻辑线程)")
            
        except Exception as e:
            self.log_text.append(f"❌ 启动行为失败: {e}")
    
    
    def on_behavior_status_changed(self, status):
        """行为状态变化处理"""
        if status == "running":
            self.status_display.setText("运行中")
            self.status_display.setStyleSheet("QLabel { color: green; font-weight: bold; }")
        elif status == "stopped":
            self.status_display.setText("已停止")
            self.status_display.setStyleSheet("QLabel { color: red; font-weight: bold; }")
    
    def on_behavior_finished(self, success):
        """行为完成处理"""
        if success:
            self.log_text.append("✅ 行为正常完成")
        else:
            self.log_text.append("⚠️ 行为被中断")
        
        # LogManager会自动处理任务记录和统计数据
        # 刷新任务历史显示
        try:
            self.refresh_task_history()
        except Exception as e:
            self.log_text.append(f"⚠️ 刷新任务历史失败: {e}")
        
        # 停止监控线程
        if self.input_monitor and self.input_monitor.isRunning():
            self.input_monitor.stop_monitoring()
            self.input_monitor.wait(1000)
        
        self.current_behavior = None
        self.input_monitor = None
    
    def on_user_input_detected(self, message):
        """用户输入检测处理"""
        self.log_text.append(f"🛑 {message} - 正在停止所有线程...")
        
        # 停止行为线程
        if self.current_behavior and self.current_behavior.isRunning():
            self.current_behavior.stop_behavior()
        
        # 停止监控线程
        if self.input_monitor and self.input_monitor.isRunning():
            self.input_monitor.stop_monitoring()
        
        self.log_text.append("🛑 所有线程已停止")
        
    def get_deltaforce_processes(self):
        """获取所有DeltaForce进程信息"""
        try:
            # 使用独立的窗口获取函数
            from gui.window_utils import get_all_deltaforce_windows
            return get_all_deltaforce_windows()
        except Exception as e:
            print(f"获取进程信息失败: {e}")
            return []
    
    def is_window_minimized(self, process):
        """检查窗口是否被最小化（位置为负数）"""
        win_info = process['window_info']
        # 兼容不同的字段名
        x = win_info.get('x', win_info.get('left', 0))
        y = win_info.get('y', win_info.get('top', 0))
        return x < 0 and y < 0
    
    def classify_processes(self, processes):
        """根据窗口大小分类进程为主进程和辅进程，考虑最小化状态"""
        if len(processes) == 0:
            return [], []
        elif len(processes) == 1:
            # 单个进程时，保持或设置为主进程
            hwnd = processes[0]['hwnd']
            self.process_roles[hwnd] = 'main'
            return processes, []
        else:
            # 多个进程的情况
            # 检查是否有窗口被最小化
            minimized_processes = [p for p in processes if self.is_window_minimized(p)]
            normal_processes = [p for p in processes if not self.is_window_minimized(p)]
            
            # 如果有窗口被最小化，保持现有角色分配
            if minimized_processes:
                main_processes = []
                aux_processes = []
                
                for process in processes:
                    hwnd = process['hwnd']
                    # 如果之前有角色记录，保持不变
                    if hwnd in self.process_roles:
                        if self.process_roles[hwnd] == 'main':
                            main_processes.append(process)
                        else:
                            aux_processes.append(process)
                    else:
                        # 新进程，如果没有主进程则设为主进程
                        if not main_processes:
                            self.process_roles[hwnd] = 'main'
                            main_processes.append(process)
                        else:
                            self.process_roles[hwnd] = 'aux'
                            aux_processes.append(process)
                
                return main_processes, aux_processes
            
            else:
                # 所有窗口都正常显示，按窗口大小重新分类
                sorted_processes = sorted(processes, 
                                        key=lambda p: p['window_info']['width'] * p['window_info']['height'])
                
                # 最小的作为主进程，其余作为辅进程
                main_processes = [sorted_processes[0]]
                aux_processes = sorted_processes[1:]
                
                # 更新角色记录
                for process in main_processes:
                    self.process_roles[process['hwnd']] = 'main'
                for process in aux_processes:
                    self.process_roles[process['hwnd']] = 'aux'
                
                return main_processes, aux_processes
    
    def create_process_widget(self, process_info, is_main=True):
        """创建单个进程的显示组件"""
        widget = QFrame()
        widget.setFrameStyle(QFrame.Box)
        widget.setStyleSheet("QFrame { border: 2px solid #ddd; border-radius: 8px; padding: 10px; margin: 5px; }")
        
        layout = QHBoxLayout(widget)
        
        # 左侧状态指示器
        status_widget = QLabel()
        status_widget.setFixedSize(60, 60)
        status_widget.setAlignment(Qt.AlignCenter)
        status_widget.setStyleSheet(f"""
            QLabel {{
                background-color: {'#f1c40f' if is_main else '#27ae60'};
                color: white;
                font-weight: bold;
                font-size: 16px;
                border-radius: 8px;
            }}
        """)
        status_widget.setText("主" if is_main else "辅")
        layout.addWidget(status_widget)
        
        # 右侧信息区域
        info_layout = QVBoxLayout()
        
        # 进程标题
        title_label = QLabel(f"{'主进程' if is_main else '辅进程'}: {process_info['title']}")
        title_label.setFont(QFont("", 12, QFont.Bold))
        info_layout.addWidget(title_label)
        
        # 窗口句柄
        hwnd_label = QLabel(f"句柄: {process_info['hwnd']}")
        hwnd_label.setStyleSheet("color: #666; font-size: 10px; font-family: 'Consolas', monospace;")
        info_layout.addWidget(hwnd_label)
        
        # 窗口位置和大小
        win_info = process_info['window_info']
        pos_label = QLabel(f"位置: ({win_info['left']}, {win_info['top']})")
        size_label = QLabel(f"大小: {win_info['width']} × {win_info['height']}")
        
        # 统一样式设置
        for label in [pos_label, size_label]:
            label.setStyleSheet("color: #666; font-size: 10px; font-family: 'Consolas', monospace;")
            info_layout.addWidget(label)
        
        layout.addLayout(info_layout)
        layout.addStretch()
        
        return widget
    
    def update_process_info(self):
        """更新进程信息显示"""
        try:
            # 获取当前进程
            current_processes = self.get_deltaforce_processes()
            
            # 检查进程是否有变化
            current_hwnds = [p['hwnd'] for p in current_processes]
            last_hwnds = [p['hwnd'] for p in self.last_processes]
            
            if current_hwnds != last_hwnds:
                # 进程有变化，更新显示
                self.refresh_process_display(current_processes)
                self.last_processes = current_processes
                
        except Exception as e:
            print(f"更新进程信息失败: {e}")
    
    def refresh_process_display(self, processes):
        """刷新进程显示"""
        # 清除现有组件
        for widget in self.process_widgets.values():
            widget.setParent(None)
        self.process_widgets.clear()
        
        # 清理已消失进程的角色记录
        current_hwnds = [p['hwnd'] for p in processes]
        self.process_roles = {hwnd: role for hwnd, role in self.process_roles.items() 
                             if hwnd in current_hwnds}
        
        # 获取容器布局
        container_layout = self.process_container.layout()
        
        if len(processes) == 0:
            # 没有进程时显示提示
            self.no_process_label.show()
        else:
            # 隐藏提示标签
            self.no_process_label.hide()
            
            # 分类进程
            main_processes, aux_processes = self.classify_processes(processes)
            
            # 显示主进程
            for process in main_processes:
                widget = self.create_process_widget(process, is_main=True)
                self.process_widgets[process['hwnd']] = widget
                container_layout.addWidget(widget)
            
            # 显示辅进程
            for process in aux_processes:
                widget = self.create_process_widget(process, is_main=False)
                self.process_widgets[process['hwnd']] = widget
                container_layout.addWidget(widget)
        
    def show_about(self):
        """显示关于对话框"""
        from PySide6.QtWidgets import QMessageBox, QApplication
        app_version = QApplication.instance().applicationVersion()
        QMessageBox.about(
            self, 
            "关于 DeltaForce MarketBot",
            f"DeltaForce MarketBot v{app_version}\n\n"
            "一个用于DeltaForce游戏的自动化交易工具\n\n"
            "© WintryWind"
        )
    
    def create_smooth_scroll_area(self):
        """创建支持平滑滚动的滚动区域"""
        class SmoothScrollArea(QScrollArea):
            def __init__(self, parent=None):
                super().__init__(parent)
                self.setFocusPolicy(Qt.WheelFocus)
            
            def wheelEvent(self, event: QWheelEvent):
                """处理滚轮事件，实现平滑滚动"""
                # 获取滚动条
                scrollbar = self.verticalScrollBar()
                
                # 计算滚动步长（每次滚动2个行为卡片的高度）
                scroll_step = 2 * 128  # 120px卡片高度 + 8px间距
                
                # 根据滚轮方向滚动
                if event.angleDelta().y() > 0:
                    # 向上滚动
                    new_value = max(0, scrollbar.value() - scroll_step)
                else:
                    # 向下滚动
                    new_value = min(scrollbar.maximum(), scrollbar.value() + scroll_step)
                
                scrollbar.setValue(new_value)
                event.accept()
        
        return SmoothScrollArea()
